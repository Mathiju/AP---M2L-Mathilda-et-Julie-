module com.example.ap_m2l {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires jdk.jdi;


    opens com.example.ap_m2l to javafx.fxml;
    exports com.example.ap_m2l;
}