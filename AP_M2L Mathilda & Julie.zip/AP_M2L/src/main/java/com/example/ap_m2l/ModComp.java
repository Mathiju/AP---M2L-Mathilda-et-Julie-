package com.example.ap_m2l;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class ModComp implements Initializable {
    @FXML
    private Button Button_modifyModifComp;
    @FXML
    private TextField TextF_ModifComp_2;
    @FXML
    private TextField TextF_ModifComp_3;
    @FXML
    private TextField TextF_ModifComp_4;
    @FXML
    private Button Button_retour;

    private TabComp comp;
    private TabComp parentController;

    /**
     * Définit la compétition à modifier.
     *
     * @param comp La compétition à modifier.
     */
    public void setComp(TabComp comp) {
        this.comp = comp;
        TextF_ModifComp_2.setText(comp.getNomco());
        TextF_ModifComp_3.setText(comp.getDatedco());
        TextF_ModifComp_4.setText(comp.getDatefco());
    }

    /**
     * Définit le contrôleur parent pour rafraîchir les données après modification.
     *
     * @param parentController Le contrôleur parent.
     */
    public void setParentController(TabComp parentController) {
        this.parentController = parentController;
    }

    /**
     * Méthode d'initialisation appelée après le chargement du fichier FXML.
     *
     * @param url             L'URL utilisée pour résoudre le fichier FXML.
     * @param resourceBundle  Les ressources utilisées pour localiser le fichier FXML.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Button_modifyModifComp.setOnAction(actionEvent -> handleSaveButton());
        Button_retour.setOnAction(this::handleRetourButton);
    }

    /**
     * Gère l'action du bouton d'enregistrement (modifier la compétition).
     */
    private void handleSaveButton() {
        String updatedNom = TextF_ModifComp_2.getText();
        String updatedDateDComp = TextF_ModifComp_3.getText();
        String updatedDateFComp = TextF_ModifComp_4.getText();

        try {
            Connection con = DBConnexion.getConnection();
            PreparedStatement pre = con.prepareStatement(
                    "UPDATE competition SET nomcomp = ?, dateDcomp = ?, dateFcomp = ? WHERE idcompetition = ?");
            pre.setString(1, updatedNom);
            pre.setString(2, updatedDateDComp);
            pre.setString(3, updatedDateFComp);
            pre.setInt(4, comp.getIdcompetition());
            pre.executeUpdate();

            comp.setNomco(updatedNom);
            comp.setDatedco(updatedDateDComp);
            comp.setDatefco(updatedDateFComp);

            // Fermer la fenêtre de modification
            Stage stage = (Stage) Button_modifyModifComp.getScene().getWindow();
            stage.close();

            // Rafraîchir le tableau principal
            parentController.refreshTableData();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Gère l'action du bouton retour (retourner à l'accueil).
     *
     * @param actionEvent L'événement d'action du bouton.
     */
    private void handleRetourButton(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) Button_retour.getScene().getWindow();
            stage.setScene(new Scene(root, 1200, 700));
            stage.setMaxHeight(700);
            stage.setMinWidth(1200);
            stage.setTitle("Accueil");
            stage.show();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
