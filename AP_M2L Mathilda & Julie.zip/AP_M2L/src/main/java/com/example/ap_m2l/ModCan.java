package com.example.ap_m2l;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class ModCan implements Initializable {
    @FXML
    private AnchorPane AnchorPane_ModifyCan;
    @FXML
    private Button Button_modifyModifCan;
    @FXML
    private Button Button_retour;
    @FXML
    private TextField TextF_ModifCan_2;
    @FXML
    private TextField TextF_ModifCan_3;
    @FXML
    private TextField TextF_ModifCan_4;
    @FXML
    private TextField TextF_ModifCan_5;
    @FXML
    private TextField TextF_ModifCan_6;

    private TabCan candidat;
    private TabCan parentController;

    public void setCandidat(TabCan candidat) {
        this.candidat = candidat;
        TextF_ModifCan_2.setText(candidat.getNomcandidat());
        TextF_ModifCan_3.setText(candidat.getPrenomcandidat());
        TextF_ModifCan_4.setText(candidat.getDncandidat());
        TextF_ModifCan_5.setText(candidat.getSexecandidat());
        TextF_ModifCan_6.setText(candidat.getMailcandidat());
    }

    public void setParentController(TabCan parentController) {
        this.parentController = parentController;
    }
    public void refreshTableData() {
        if (parentController != null) {
            parentController.refreshTableData();
        }
    }
    //******************************************************************
    // Méthode Initialize
    //******************************************************************
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //******************************************************************
        // Initialisation des boutons
        //******************************************************************
        Button_modifyModifCan.setOnAction(actionEvent -> handleSaveButton());
        Button_retour.setOnAction(this::handleRetourButton);
    }
    //******************************************************************
    // Utilisation du bouton enregistré (modifier candidat)
    //******************************************************************
    private void handleSaveButton() {
        String updatedNom = TextF_ModifCan_2.getText();
        String updatedPrenom = TextF_ModifCan_3.getText();
        String updatedDN = TextF_ModifCan_4.getText();
        String updatedSexe = TextF_ModifCan_5.getText();
        String updatedMail = TextF_ModifCan_6.getText();

        try {
            Connection con = DBConnexion.getConnection();
            PreparedStatement pre = con.prepareStatement(
                    "UPDATE candidat SET nomcandidat = ?, prenomcandidat = ?, datenaisscandidat = ?, sexecandidat = ?, mailcandidat = ? WHERE idcandidat = ?");
            pre.setString(1, updatedNom);
            pre.setString(2, updatedPrenom);
            pre.setString(3, updatedDN);
            pre.setString(4, updatedSexe);
            pre.setString(5, updatedMail);
            pre.setInt(6, candidat.getIdcandidat());
            pre.executeUpdate();

            candidat.setNomcandidat(updatedNom);
            candidat.setPrenomcandidat(updatedPrenom);
            candidat.setDncandidat(updatedDN);
            candidat.setSexecandidat(updatedSexe);
            candidat.setMailcandidat(updatedMail);

            // Fermer la fenêtre de modification
            Stage stage = (Stage) Button_modifyModifCan.getScene().getWindow();
            stage.close();

            // Rafraîchir le tableau principal
            parentController.refreshTableData();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    //******************************************************************
    // Utilisation du bouton retour (candidat vers accueil)
    //******************************************************************
    private void handleRetourButton(ActionEvent actionEvent) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
        try {
            Parent root = loader.load();
            Stage stage = (Stage) Button_retour.getScene().getWindow();
            stage.setScene(new Scene(root, 1200, 700));
            stage.setMaxHeight(700);
            stage.setMinWidth(1200);
            stage.setTitle("Accueil");
            stage.show();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
