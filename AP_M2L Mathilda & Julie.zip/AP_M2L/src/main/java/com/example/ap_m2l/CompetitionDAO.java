package com.example.ap_m2l;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CompetitionDAO {

    public List<Competition> getAllCompetitions() {
        List<Competition> competitions = new ArrayList<>();
        try (Connection con = DBConnexion.getConnection();
             PreparedStatement stmt = con.prepareStatement("SELECT * FROM competition")) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Competition comp = new Competition();
                comp.setId(rs.getInt("id"));
                comp.setNom(rs.getString("nom"));
                competitions.add(comp);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return competitions;
    }

    public void addCompetition(Competition competition) throws SQLException {
        try (Connection con = DBConnexion.getConnection();
             PreparedStatement stmt = con.prepareStatement("INSERT INTO competition (nomcomp, dateDcomp, dateFcomp)VALUES (?,?,?)")) {
            stmt.setString(1, competition.getNom());
            stmt.executeUpdate();
        }
    }



    public Competition getCompetitionById(int competitionId) {
        return null;
    }
}
