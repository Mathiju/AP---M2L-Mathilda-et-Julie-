package com.example.ap_m2l;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;

public class TabEquipe implements Initializable {

    @FXML
    private TableView<TabEquipe> TableView;
    @FXML
    private TableColumn<TabEquipe, Integer> TC_TableEq_ID;
    @FXML
    private TableColumn<TabEquipe, String> TC_TableEq_nom;
    @FXML
    public TableColumn<TabEquipe, String> TC_TableEq_nomComp;
    @FXML
    private Button Button_modifyTableEquipe;
    @FXML
    private Button Button_deletTableComp;
    @FXML
    private Button Button_retour;

    private String nomequipe;
    private int idcandidat;
    private String nomcomp;

    private ObservableList<TabEquipe> observableList = FXCollections.observableArrayList();

    // Getters and Setters
    public String getNomequipe() {
        return nomequipe;
    }

    public void setNomequipe(String nomequipe) {
        this.nomequipe = nomequipe;
    }

    public int getIdcandidat() {
        return idcandidat;
    }

    public void setIdcandidat(int idcandidat) {
        this.idcandidat = idcandidat;
    }

    public String getNomcomp() {
        return nomcomp;
    }

    public void setNomcomp(String nomcomp) {
        this.nomcomp = nomcomp;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Button_retour.setOnAction(this::handleRetourButton);
        Button_modifyTableEquipe.setOnAction(this::handleModifyButton);
        Button_deletTableComp.setOnAction(this::handleDeleteButton);

        // Configuration des colonnes du tableau
        TC_TableEq_nom.setCellValueFactory(new PropertyValueFactory<>("nomequipe"));
        TC_TableEq_ID.setCellValueFactory(new PropertyValueFactory<>("idcandidat"));
        TC_TableEq_nomComp.setCellValueFactory(new PropertyValueFactory<>("nomcomp"));

        // Chargement des données depuis la base de données
        loadTableData();
    }

    // Méthode pour rafraîchir les données du tableau à partir de la base de données
    public void refreshTableData() {
        observableList.clear(); // Effacer les anciennes données
        loadTableData(); // Recharger les données
    }

    private void handleRetourButton(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) Button_retour.getScene().getWindow();
            stage.setScene(new Scene(root, 1200, 700));
            stage.setMaxHeight(700);
            stage.setMinWidth(1200);
            stage.setTitle("Ajout de Compétition");
            stage.show();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void handleModifyButton(ActionEvent actionEvent) {
        TabEquipe selectedEquipe = TableView.getSelectionModel().getSelectedItem();
        if (selectedEquipe != null) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("modify_equipe.fxml"));
                Parent root = loader.load();

                // Passer l'équipe sélectionnée au contrôleur de modification
                ModEquipe controller = loader.getController();
                controller.setEquipe(selectedEquipe);
                controller.setParentController(this); // Pass the parent controller

                Stage stage = new Stage();
                stage.setScene(new Scene(root));
                stage.setTitle("Modifier l'équipe");
                stage.show();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        } else {
            Alert noSelectionAlert = new Alert(Alert.AlertType.INFORMATION);
            noSelectionAlert.setTitle("Information");
            noSelectionAlert.setContentText("Merci de sélectionner une ligne pour la modifier.");
            noSelectionAlert.showAndWait();
        }
    }

    private void handleDeleteButton(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Attention");
        alert.setContentText("Êtes-vous sûr? Voulez-vous vraiment supprimer cette ligne?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            TabEquipe selectedEquipe = TableView.getSelectionModel().getSelectedItem();
            if (selectedEquipe != null) {
                try {
                    Connection con = DBConnexion.getConnection();
                    PreparedStatement pre = con.prepareStatement("DELETE FROM equipe WHERE idcandidat = ?");
                    pre.setInt(1, selectedEquipe.getIdcandidat());
                    pre.executeUpdate();

                    // Retirer l'équipe supprimée de la liste observable
                    observableList.remove(selectedEquipe);

                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            } else {
                Alert noSelectionAlert = new Alert(Alert.AlertType.INFORMATION);
                noSelectionAlert.setTitle("Information");
                noSelectionAlert.setContentText("Merci de sélectionner une ligne pour la supprimer.");
                noSelectionAlert.showAndWait();
            }
        }
    }

    private void loadTableData() {
        try {
            Connection con = DBConnexion.getConnection();
            PreparedStatement pre = con.prepareStatement("SELECT * FROM equipe");
            ResultSet rs = pre.executeQuery();

            while (rs.next()) {
                TabEquipe tabE = new TabEquipe();
                tabE.setNomequipe(rs.getString("nomequipe"));
                tabE.setIdcandidat(rs.getInt("idcandidat"));
                tabE.setNomcomp(rs.getString("nomcomp"));
                observableList.add(tabE);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        TC_TableEq_nom.setCellValueFactory(new PropertyValueFactory<>("nomequipe"));
        TC_TableEq_ID.setCellValueFactory(new PropertyValueFactory<>("idcandidat"));
        TC_TableEq_nomComp.setCellValueFactory(new PropertyValueFactory<>("nomcomp"));

        TableView.setItems(observableList);
    }

    public void setCompetitionId(int competitionId) {
    }

    public void setId(int id) {
    }

    public int getCompetitionId() {
        return 0;
    }

    public int getId() {
        return 0;
    }
}
