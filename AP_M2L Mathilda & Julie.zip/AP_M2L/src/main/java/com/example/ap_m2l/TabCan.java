package com.example.ap_m2l;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;

public class TabCan implements Initializable {
    // Déclaration des éléments de l'interface
    @FXML
    private Button Button_modifyTableCan;
    @FXML
    private Button Button_deletTableCan;
    @FXML
    private Button Button_retour;
    @FXML
    private Button Button_addTableCan;
    @FXML
    private TableView<TabCan> TableView;
    @FXML
    private TableColumn<TabCan, Integer> TC_TableCan_ID;
    @FXML
    private TableColumn<TabCan, String> TC_TableCan_nom;
    @FXML
    private TableColumn<TabCan, String> TC_TableCan_prenom;
    @FXML
    private TableColumn<TabCan, String> TC_TableCan_DN;
    @FXML
    private TableColumn<TabCan, String> TC_TableCan_sexe;
    @FXML
    private TableColumn<TabCan, String> TC_TableCan_mail;

    private ObservableList<TabCan> observableList = FXCollections.observableArrayList();
    private final String table = "candidat";
    private final String ligne = "idcandidat";

    // Déclaration des attributs de la classe
    private int idcandidat;
    private String nomcandidat, prenomcandidat, dncandidat, sexecandidat, mailcandidat;

    //******************************************************************
    // Getter and Setter
    //******************************************************************
    public void refreshTable() {
        TableView.refresh();
    }

    public String getNomcandidat() {
        return nomcandidat;
    }

    public void setNomcandidat(String nomcandidat) {
        this.nomcandidat = nomcandidat;
    }

    public String getPrenomcandidat() {
        return prenomcandidat;
    }

    public void setPrenomcandidat(String prenomcandidat) {
        this.prenomcandidat = prenomcandidat;
    }

    public String getDncandidat() {
        return dncandidat;
    }

    public void setDncandidat(String dncandidat) {
        this.dncandidat = dncandidat;
    }

    public String getSexecandidat() {
        return sexecandidat;
    }

    public void setSexecandidat(String sexecandidat) {
        this.sexecandidat = sexecandidat;
    }

    public String getMailcandidat() {
        return mailcandidat;
    }

    public void setMailcandidat(String mailcandidat) {
        this.mailcandidat = mailcandidat;
    }

    public int getIdcandidat() {
        return idcandidat;
    }

    public void setIdcandidat(int idcandidat) {
        this.idcandidat = idcandidat;
    }

    //******************************************************************
    // Méthode Initialize
    //******************************************************************
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Initialisation des boutons
        Button_retour.setOnAction(actionEvent -> handleRetourButton());
        Button_modifyTableCan.setOnAction(actionEvent -> handleModifyButton());
        Button_deletTableCan.setOnAction(actionEvent -> handleDeleteButton());

        // Chargement des données dans la TableView
        loadTableData();

        // Rafraîchissement de la table après chaque modification
        refreshTableData();
    }

    // Méthode pour rafraîchir les données du tableau à partir de la base de données
    public void refreshTableData() {
        observableList.clear(); // Effacer les anciennes données

        // Recharger les données du tableau à partir de la base de données
        loadTableData();
    }

    //******************************************************************
    // Code du bouton retour (tableau candidat vers accueil)
    //******************************************************************
    private void handleRetourButton() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) Button_retour.getScene().getWindow();
            stage.setScene(new Scene(root, 1200, 700));
            stage.setMaxHeight(700);
            stage.setMinWidth(1200);
            stage.setTitle("Bienvenue !");
            stage.show();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    //******************************************************************
    // Code du bouton modifier (tableau candidat)
    //******************************************************************
    private void handleModifyButton() {
        TabCan selectedCandidat = TableView.getSelectionModel().getSelectedItem();
        if (selectedCandidat != null) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("modify_candidat.fxml"));
                Parent root = loader.load();

                ModCan controller = loader.getController();
                controller.setCandidat(selectedCandidat);

                Stage stage = new Stage();
                stage.setScene(new Scene(root));
                stage.setTitle("Modifier le Candidat");
                stage.show();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        } else {
            Alert noSelectionAlert = new Alert(Alert.AlertType.INFORMATION);
            noSelectionAlert.setTitle("Information");
            noSelectionAlert.setContentText("Merci de sélectionner une ligne pour la modifier.");
            noSelectionAlert.showAndWait();
        }
    }


    //******************************************************************
    // Code du bouton supprimer (tableau candidat)
    //******************************************************************
    private void handleDeleteButton() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Attention");
        alert.setContentText("Êtes-vous sûr ? Voulez-vous vraiment supprimer cette ligne ?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            TabCan selectedCan = TableView.getSelectionModel().getSelectedItem();
            if (selectedCan != null) {
                try {
                    Connection con = DBConnexion.getConnection();
                    PreparedStatement pre = con.prepareStatement("DELETE FROM " + table + " WHERE " + ligne + " = ?");
                    pre.setInt(1, selectedCan.getIdcandidat());
                    pre.executeUpdate();

                    observableList.remove(selectedCan);
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            } else {
                Alert noSelectionAlert = new Alert(Alert.AlertType.INFORMATION);
                noSelectionAlert.setTitle("Information");
                noSelectionAlert.setContentText("Merci de sélectionner une ligne pour la supprimer.");
                noSelectionAlert.showAndWait();
            }
        }
    }

    //******************************************************************
    // Chargement des données dans la TableView
    //******************************************************************
    private void loadTableData() {
        try {
            Connection con = DBConnexion.getConnection();
            PreparedStatement pre = con.prepareStatement("SELECT * FROM candidat");
            ResultSet rs = pre.executeQuery();

            while (rs.next()) {
                TabCan tabCan = new TabCan();
                tabCan.setIdcandidat(rs.getInt("idcandidat"));
                tabCan.setNomcandidat(rs.getString("nomcandidat"));
                tabCan.setPrenomcandidat(rs.getString("prenomcandidat"));
                tabCan.setDncandidat(rs.getString("datenaisscandidat"));
                tabCan.setSexecandidat(rs.getString("sexecandidat"));
                tabCan.setMailcandidat(rs.getString("mailcandidat"));

                observableList.add(tabCan);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        TC_TableCan_ID.setCellValueFactory(new PropertyValueFactory<>("idcandidat"));
        TC_TableCan_nom.setCellValueFactory(new PropertyValueFactory<>("nomcandidat"));
        TC_TableCan_prenom.setCellValueFactory(new PropertyValueFactory<>("prenomcandidat"));
        TC_TableCan_DN.setCellValueFactory(new PropertyValueFactory<>("dncandidat"));
        TC_TableCan_sexe.setCellValueFactory(new PropertyValueFactory<>("sexecandidat"));
        TC_TableCan_mail.setCellValueFactory(new PropertyValueFactory<>("mailcandidat"));

        TableView.setItems(observableList);
    }
}
