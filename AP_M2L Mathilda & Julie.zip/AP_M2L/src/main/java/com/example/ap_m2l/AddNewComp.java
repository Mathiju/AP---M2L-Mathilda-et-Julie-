package com.example.ap_m2l;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.ResourceBundle;

public class AddNewComp implements Initializable {

    public Button Button_addComp;

    public TextField TF_addComp_nom;
    public TextField TF_addComp_dateDeb;
    public TextField TF_addComp_dateFin;
    public AnchorPane AnchorPane_addCan;
    public static String  input_nomcomp, input_dateDcomp, input_dateFcomp;
    public PreparedStatement pre;
    public ResultSet rs;
    public static String path;
    public TextField TF_addComp_neq;
    public AnchorPane AnchorPane_addComp;

    @FXML
    private Button Button_retour;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Button_retour.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
                try {
                    Parent root = loader.load();
                    Stage stage = (Stage) Button_retour.getScene().getWindow();
                    stage.setScene(new Scene(root, 1200, 700));
                    stage.setMaxHeight(700);
                    stage.setMinWidth(1200);
                    stage.setTitle("Ajout de Compétition");
                    stage.show();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        /*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/

        Button_addComp.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
// Récupération des détails du véhicule à partir des champs de texte et des menus déroulants
                input_nomcomp = TF_addComp_nom.getText();
                input_dateDcomp = TF_addComp_dateDeb.getText();
                input_dateFcomp = TF_addComp_dateFin.getText();

// Vérification que tous les champs obligatoires sont remplis
                if (input_nomcomp.trim().isEmpty()) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Input error");
                    alert.setContentText("Les champs de saisie ne peuvent pas être vides.");
                    alert.show();
                    return;
                } else {
                    try {

// Établissement d'une connexion à la base de données
                        Connection con = DBConnexion.getConnection();

// Préparation de la requête SQL pour l'insertion des détails du véhicule
                        PreparedStatement pre = con.prepareStatement("INSERT INTO competition (nomcomp, dateDcomp, dateFcomp)VALUES (?,?,?)");
                        pre.setString(1, input_nomcomp);
                        pre.setString(2, input_dateDcomp);
                        pre.setString(3, input_dateFcomp);


// Exécution de la requête SQL pour insérer les détails du véhicule dans la base de données
                        pre.executeUpdate();

// Chargement de la nouvelle interface utilisateur affichant une table de véhicules
                        FXMLLoader loader = new FXMLLoader(AddNewComp.class.getResource("Table_competition.fxml"));
                        Parent root = loader.load();
                        Stage stage = (Stage) Button_addComp.getScene().getWindow();
                        stage.setScene(new Scene(root, 1200, 900));
                        stage.setMaxWidth(1200);
                        stage.setMaxHeight(900);
                        stage.setTitle("Tableau compétition");
                        stage.show();

                    } catch (SQLException | IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        });
    };
}


