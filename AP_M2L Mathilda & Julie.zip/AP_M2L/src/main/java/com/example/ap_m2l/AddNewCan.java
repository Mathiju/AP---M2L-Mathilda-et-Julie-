package com.example.ap_m2l;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.ResourceBundle;

public class AddNewCan implements Initializable {

    public Button Button_addCan;
    public TextField TF_NomaddCan;
    public TextField TF_PrenomaddCan;
    public TextField TF_DateNaissAddCan;
    public TextField TF_SexeaddCan;
    public TextField TF_MailAddCan;
    public AnchorPane AnchorPane_addCan;
    public ImageView ImageView_addCan;
    public Label Label_addCan;
    public static String  input_prenomcandidat, input_datenaissancecandidat, input_mailcandidat, input_nomcandidat, input_sexecandidat;
    public PreparedStatement pre;
    public ResultSet rs;
    public static String path;
    @FXML
    private Button Button_retour;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Button_retour.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
                try {
                    Parent root = loader.load();
                    Stage stage = (Stage) Button_retour.getScene().getWindow();
                    stage.setScene(new Scene(root, 1200, 700));
                    stage.setMaxHeight(700);
                    stage.setMinWidth(1200);
                    stage.setTitle("Ajout de Compétition");
                    stage.show();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });

        /*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/

        Button_addCan.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
// Récupération des détails du véhicule à partir des champs de texte et des menus déroulant/
                input_nomcandidat = TF_NomaddCan.getText();
                input_prenomcandidat = TF_PrenomaddCan.getText();
                input_datenaissancecandidat = TF_DateNaissAddCan.getText();
                input_sexecandidat = TF_SexeaddCan.getText();
                input_mailcandidat = TF_MailAddCan.getText();


// Vérification que tous les champs obligatoires sont remplis
                if (input_nomcandidat.trim().isEmpty()) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Input error");
                    alert.setContentText("Input or select fields cannot be empty");
                    alert.show();
                    return;
                } else {
// Conversion des valeurs numériques en types appropriés


                    try {
// Ouverture d'un flux d'entrée pour lire l'image sélectionnée


// Établissement d'une connexion à la base de données
                        Connection con = DBConnexion.getConnection();

// Préparation de la requête SQL pour l'insertion des détails du véhicule
                        PreparedStatement pre = con.prepareStatement("INSERT INTO candidat (nomcandidat, prenomcandidat, datenaisscandidat, sexecandidat, mailcandidat)VALUES (?,?,?,?,?)");
                        pre.setString(1, input_nomcandidat);
                        pre.setString(2, input_prenomcandidat);
                        pre.setString(3, input_datenaissancecandidat);
                        pre.setString(4, input_sexecandidat);
                        pre.setString(5, input_mailcandidat);


// Exécution de la requête SQL pour insérer les détails du véhicule dans la base de données
                        pre.executeUpdate();

// Chargement de la nouvelle interface utilisateur affichant une table de véhicules
                        FXMLLoader loader = new FXMLLoader(AddNewCan.class.getResource("Table_candidat.fxml"));
                        Parent root = loader.load();
                        Stage stage = (Stage) Button_addCan.getScene().getWindow();
                        stage.setScene(new Scene(root, 1200, 900));
                        stage.setMaxWidth(1200);
                        stage.setMaxHeight(900);
                        stage.setTitle("Tableau candidat");
                        stage.show();

                    } catch (SQLException | IOException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        });
    };
}
