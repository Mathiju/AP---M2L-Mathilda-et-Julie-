package com.example.ap_m2l;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class AddNewEquipe implements Initializable {

    @FXML
    private Button Button_retour;
    @FXML
    private TableView TabIDCan_addeq;
    @FXML
    private TableView TabNomComp_addeq;
    @FXML
    private Button Button_addEquipeCan;
    @FXML
    private Button Button_addEquipeComp;
    @FXML
    private ImageView ImageView_addEquipe;
    @FXML
    private TextField TF_addEquipe_nom;
    @FXML
    private TextField TF_addEquipe_idCan;
    @FXML
    private TextField TF_addEquipe_ncomp;

    @FXML
    private Button Button_addEquipe;

    private final EquipeDAO equipeDAO = new EquipeDAO();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        Button_addEquipe.setOnAction(this::handleAddEquipe);
        Button_retour.setOnAction(this::handleReturn);
    }

    @FXML
    private void handleAddEquipe(ActionEvent event) {
        String nomequipe = TF_addEquipe_nom.getText();
        String idcandidatStr = TF_addEquipe_idCan.getText();
        String nomcomp = TF_addEquipe_ncomp.getText();

        System.out.println("Button clicked");
        System.out.println("Nomequipe: " + nomequipe);
        System.out.println("IdCandidatStr: " + idcandidatStr);
        System.out.println("NomComp: " + nomcomp);

        if (nomequipe.trim().isEmpty() || idcandidatStr.trim().isEmpty() || nomcomp.trim().isEmpty() ) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur de saisie");
            alert.setContentText("Les champs de saisie ne peuvent pas être vides");
            alert.show();
            return;
        }

        int idcandidat, competitionId;
        try {
            idcandidat = Integer.parseInt(idcandidatStr);
        } catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur de saisie");
            alert.setContentText("ID Candidat et ID Compétition doivent être des nombres");
            alert.show();
            return;
        }

        TabEquipe newEquipe = new TabEquipe();
        newEquipe.setNomequipe(nomequipe);
        newEquipe.setIdcandidat(idcandidat);
        newEquipe.setNomcomp(nomcomp);

        try {
            equipeDAO.addEquipe(newEquipe);

            // Show confirmation message
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Succès");
            alert.setContentText("Équipe ajoutée avec succès");
            alert.show();

            // Clear input fields
            TF_addEquipe_nom.clear();
            TF_addEquipe_idCan.clear();
            TF_addEquipe_ncomp.clear();

        } catch (SQLException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur de base de données");
            alert.setContentText("Erreur lors de l'insertion des données : " + e.getMessage());
            alert.show();
        }
    }

    @FXML
    private void handleReturn(ActionEvent event) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
        try {
            Parent root = loader.load();
            Stage stage = (Stage) Button_retour.getScene().getWindow();
            stage.setScene(new Scene(root, 1200, 700));
            stage.setMaxHeight(700);
            stage.setMinWidth(1200);
            stage.setTitle("Ajout de Compétition");
            stage.show();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
