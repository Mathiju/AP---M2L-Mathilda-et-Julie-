package com.example.ap_m2l;

import com.example.ap_m2l.DBConnexion;
import com.example.ap_m2l.TabEquipe;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EquipeDAO {

    public List<TabEquipe> getAllEquipes() {
        List<TabEquipe> equipes = new ArrayList<>();
        try (Connection con = DBConnexion.getConnection();
             PreparedStatement stmt = con.prepareStatement("SELECT * FROM equipe")) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                TabEquipe equipe = new TabEquipe();
                equipe.setId(rs.getInt("id"));
                equipe.setNomequipe(rs.getString("nomequipe"));
                equipe.setIdcandidat(rs.getInt("idcandidat"));
                equipe.setNomcomp(rs.getString("nomcomp"));
                equipe.setCompetitionId(rs.getInt("competition_id"));
                equipes.add(equipe);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return equipes;
    }

    public void addEquipe(TabEquipe equipe) throws SQLException {
        String query = "INSERT INTO equipe (nomequipe, idcandidat, nomcomp, competition_id) VALUES (?, ?, ?, ?)";
        try (Connection con = DBConnexion.getConnection();
             PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setString(1, equipe.getNomequipe());
            stmt.setInt(2, equipe.getIdcandidat());
            stmt.setString(3, equipe.getNomcomp());
            stmt.setInt(4, equipe.getCompetitionId());
            stmt.executeUpdate();
        }
    }

    public void updateEquipe(TabEquipe equipe) throws SQLException {
        String query = "UPDATE equipe SET nomequipe = ?, idcandidat = ?, nomcomp = ?, competition_id = ? WHERE id = ?";
        try (Connection con = DBConnexion.getConnection();
             PreparedStatement stmt = con.prepareStatement(query)) {
            stmt.setString(1, equipe.getNomequipe());
            stmt.setInt(2, equipe.getIdcandidat());
            stmt.setString(3, equipe.getNomcomp());
            stmt.setInt(4, equipe.getCompetitionId());
            stmt.setInt(5, equipe.getId());
            stmt.executeUpdate();
        }
    }
}
