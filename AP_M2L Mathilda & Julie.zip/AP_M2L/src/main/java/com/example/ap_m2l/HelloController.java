package com.example.ap_m2l;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class HelloController implements Initializable {
    
    public AnchorPane AnchorPane_helloV;
    public Menu MenuComp_helloV;
    public MenuItem MenuItem_tabComp_helloV;
    public Menu MenuCan_helloV;
    public MenuItem MenuItem_addCan_helloV;
    public MenuItem MenuItem_tabCan_helloV;
    public Menu MenuEquipe_helloV;
    public MenuItem MenuItem_addEquipe_helloV;
    public MenuItem MenuItem_tabEquipe_helloV;
    @FXML
    MenuItem MenuItem_addComp_helloV;
    @FXML
    MenuBar MenuBar_helloV;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        MenuItem_addComp_helloV.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                FXMLLoader loader = new FXMLLoader(AddNewComp.class.getResource("add_competition.fxml"));
                try {
                    Parent root = loader.load();
                    Stage stage = (Stage) MenuBar_helloV.getScene().getWindow();
                    stage.setScene(new Scene(root, 1200, 700));
                    stage.setMaxHeight(700);
                    stage.setMinWidth(1200);
                    stage.setTitle("Ajout de Compétition");
                    stage.show();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        MenuItem_tabComp_helloV.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                FXMLLoader loader = new FXMLLoader(TabComp.class.getResource("table_competition.fxml"));
                try {
                    Parent root = loader.load();
                    Stage stage = (Stage) MenuBar_helloV.getScene().getWindow();
                    stage.setScene(new Scene(root, 1200, 700));
                    stage.setMaxHeight(700);
                    stage.setMaxWidth(1200);
                    stage.setTitle("Tableau compétition");
                    stage.show();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        MenuItem_addCan_helloV.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                FXMLLoader loader = new FXMLLoader(AddNewCan.class.getResource("add_candidat.fxml"));
                try {
                    Parent root = loader.load();
                    Stage stage = (Stage) MenuBar_helloV.getScene().getWindow();
                    stage.setScene(new Scene(root, 1200, 700));
                    stage.setMaxHeight(700);
                    stage.setMinWidth(1200);
                    stage.setTitle("Ajout de candidat");
                    stage.show();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        MenuItem_tabCan_helloV.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                FXMLLoader loader = new FXMLLoader(TabCan.class.getResource("table_candidat.fxml"));
                try {
                    Parent root = loader.load();
                    Stage stage = (Stage) MenuBar_helloV.getScene().getWindow();
                    stage.setScene(new Scene(root, 1200, 700));
                    stage.setMaxHeight(700);
                    stage.setMaxWidth(1200);
                    stage.setTitle("Tableau candidat");
                    stage.show();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        MenuItem_addEquipe_helloV.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                FXMLLoader loader = new FXMLLoader(AddNewEquipe.class.getResource("add_equipe.fxml"));
                try {
                    Parent root = loader.load();
                    Stage stage = (Stage) MenuBar_helloV.getScene().getWindow();
                    stage.setScene(new Scene(root, 1200, 700));
                    stage.setMaxHeight(700);
                    stage.setMinWidth(1200);
                    stage.setTitle("Ajout d'équipe");
                    stage.show();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        MenuItem_tabEquipe_helloV.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                FXMLLoader loader = new FXMLLoader(TabEquipe.class.getResource("table_equipe.fxml"));
                try {
                    Parent root = loader.load();
                    Stage stage = (Stage) MenuBar_helloV.getScene().getWindow();
                    stage.setScene(new Scene(root, 1200, 700));
                    stage.setMaxHeight(700);
                    stage.setMaxWidth(1200);
                    stage.setTitle("Tableau équipe");
                    stage.show();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }
}