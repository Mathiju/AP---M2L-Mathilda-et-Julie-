package com.example.ap_m2l;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class ModEquipe implements Initializable {
    @FXML
    private TextField TextF_ModifEquipe_2; // Nom de l'équipe
    @FXML
    private TextField TextF_ModifEquipe_4; // ID du candidat (à titre d'exemple)
    @FXML
    private Button Button_retour;
    @FXML
    private Button Button_modifyModifEquipe;

    private TabEquipe equipe;
    private TabEquipe parentController;

    public void setEquipe(TabEquipe equipe) {
        this.equipe = equipe;
        TextF_ModifEquipe_2.setText(equipe.getNomequipe());
        TextF_ModifEquipe_4.setText(String.valueOf(equipe.getIdcandidat()));
    }

    public void setParentController(TabEquipe parentController) {
        this.parentController = parentController;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Button_retour.setOnAction(actionEvent -> {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
            try {
                Parent root = loader.load();
                Stage stage = (Stage) Button_retour.getScene().getWindow();
                stage.setScene(new Scene(root, 1200, 700));
                stage.setMaxHeight(700);
                stage.setMinWidth(1200);
                stage.setTitle("Ajout de Compétition");
                stage.show();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });

        Button_modifyModifEquipe.setOnAction(this::saveChanges);
    }

    private void saveChanges(ActionEvent event) {
        String newNomEquipe = TextF_ModifEquipe_2.getText();

        // Mise à jour dans la base de données
        try {
            Connection con = DBConnexion.getConnection();
            PreparedStatement pre = con.prepareStatement("UPDATE equipe SET nomEquipe = ? WHERE idCandidat = ?");
            pre.setString(1, newNomEquipe);
            pre.setInt(2, equipe.getIdcandidat());
            pre.executeUpdate();

            // Mise à jour dans l'interface utilisateur
            equipe.setNomequipe(newNomEquipe);

            // Fermer la fenêtre de modification
            Stage stage = (Stage) Button_modifyModifEquipe.getScene().getWindow();
            stage.close();

        } catch (SQLException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur de base de données");
            alert.setContentText("Erreur lors de la mise à jour des données : " + e.getMessage());
            alert.show();
        }
    }
}
