package com.example.ap_m2l;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CandidatDAO {

    public Candidat getCandidatById(int id) {
        Candidat candidat = null;
        try (Connection con = DBConnexion.getConnection();
             PreparedStatement stmt = con.prepareStatement("SELECT * FROM candidat WHERE idcandidat = ?")) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                candidat = new Candidat();
                candidat.setId(rs.getInt("idcandidat"));
                candidat.setNom(rs.getString("nomcandidat"));
                candidat.setPrenom(rs.getString("prenomcandidat"));
                candidat.setDateNaissance(rs.getString("datenaisscandidat"));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return candidat;
    }
}

