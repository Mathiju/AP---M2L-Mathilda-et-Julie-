package com.example.ap_m2l;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;

public class TabComp implements Initializable {

    public Button Button_modifyTableComp;
    public Button Button_deletTableComp;
    public Button Button_eqTableComp;
    @FXML
    private javafx.scene.control.TableView<TabComp> TableView;
    public TableColumn<TabComp, String> TC_TableComp_ID;
    public TableColumn<TabComp, String> TC_TableComp_nom;
    public TableColumn<TabComp, String> TC_TableComp_DateD;
    public TableColumn<TabComp, String> TC_TableComp_DateF;
    private int idcomp;
    private String nomco;
    private String datedco;
    private String datefco;
    String table = "competition";
    String ligne = "idcompetition";

    //******************************************************************
    // Getter and Setter
    //******************************************************************
    public int getIdcomp() {
        return idcomp;
    }

    public void setIdcomp(int idcomp) {
        this.idcomp = idcomp;
    }

    public String getNomco() {
        return nomco;
    }

    public void setNomco(String nomco) {
        this.nomco = nomco;
    }

    public String getDatedco() {
        return datedco;
    }

    public void setDatedco(String datedco) {
        this.datedco = datedco;
    }

    public String getDatefco() {
        return datefco;
    }

    public void setDatefco(String datefco) {
        this.datefco = datefco;
    }

    @FXML
    private Button Button_retour;
    @FXML
    private ObservableList<TabComp> observableList = FXCollections.observableArrayList();
    //******************************************************************
    // Méthode Initialize
    //******************************************************************
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //******************************************************************
        // Code du bouton retour (tableau compétition vers accueil)
        //******************************************************************
        Button_retour.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
                try {
                    Parent root = loader.load();
                    Stage stage = (Stage) Button_retour.getScene().getWindow();
                    stage.setScene(new Scene(root, 1200, 700));
                    stage.setMaxHeight(700);
                    stage.setMinWidth(1200);
                    stage.setTitle("Bienvenue !");
                    stage.show();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        //******************************************************************
        // Code du bouton (tableau compétition vers tableau équipe)
        //******************************************************************
        Button_eqTableComp.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("table_equipe.fxml"));
                try {
                    Parent root = loader.load();
                    Stage stage = (Stage) Button_eqTableComp.getScene().getWindow();
                    stage.setScene(new Scene(root, 1200, 700));
                    stage.setMaxHeight(700);
                    stage.setMinWidth(1200);
                    stage.setTitle("Tableau équipe");
                    stage.show();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        //******************************************************************
        // Code du bouton modifié (tableau compétition)
        //******************************************************************
        Button_modifyTableComp.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                TabComp selectedComp = TableView.getSelectionModel().getSelectedItem();
                if (selectedComp != null) {
                    // Ouverture de la fenêtre de modification avec les détails de la compétition sélectionnée
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("modify_competition.fxml"));
                    Parent root;
                    try {
                        root = loader.load();
                        // Transmission des détails de la compétition à la fenêtre de modification
                        ModComp controller = loader.getController();
                        controller.setComp(selectedComp);
                        // Affichage de la fenêtre de modification
                        Stage stage = new Stage();
                        stage.setScene(new Scene(root));
                        stage.setTitle("Modification de Compétition");
                        stage.show();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    // Aucune compétition sélectionnée, afficher un message d'erreur
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Erreur");
                    alert.setContentText("Aucune compétition sélectionnée.");
                    alert.showAndWait();
                }
            }
        });

        //******************************************************************
        // Code du bouton supprimé (tableau compétition vers accueil)
        //******************************************************************
        Button_deletTableComp.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Attention");
                alert.setContentText("Êtes-vous sûr? Voulez-vous vraiment supprimer cette ligne?");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.isPresent() && result.get() == ButtonType.OK) {
                    // Récupérer la ligne sélectionnée dans TableView
                    TabComp selectedComp = (TabComp) TableView.getSelectionModel().getSelectedItem();
                    if (selectedComp != null) {
                        try {
                            Connection con = DBConnexion.getConnection();
                            // Préparer la requête SQL DELETE avec le paramètre idequipe
                            PreparedStatement pre = con.prepareStatement("DELETE FROM " + table + " WHERE " + ligne + " = ?");
                            // Définir la valeur de idequipe comme paramètre dans la requête
                            pre.setInt(1, selectedComp.getIdcomp());
                            // Exécuter la requête DELETE
                            pre.executeUpdate();

                            // Recharger la vue TableView pour refléter les changements
                            FXMLLoader loader = new FXMLLoader(TabEquipe.class.getResource("table_competition.fxml"));
                            Parent root = loader.load();
                            Stage stage = (Stage) Button_deletTableComp.getScene().getWindow();
                            stage.setScene(new Scene(root, 1200, 700));
                            stage.setMaxWidth(1200);
                            stage.setMaxHeight(700);
                            stage.setTitle("Tableau équipe");
                            stage.show();
                        } catch (SQLException e) {
                            throw new RuntimeException(e);
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    } else {
                        // Aucune ligne sélectionnée dans TableView
                        Alert noSelectionAlert = new Alert(Alert.AlertType.INFORMATION);
                        noSelectionAlert.setTitle("Information");
                        noSelectionAlert.setContentText("Please select a row to delete.");
                        noSelectionAlert.showAndWait();
                    }
                }
            }
        });

// la requête pour l'affichage
        try {
            Connection con = DBConnexion.getConnection();
            PreparedStatement pre = con.prepareStatement("SELECT * FROM competition");
            ResultSet rs = pre.executeQuery();
//
            while (rs.next()) {
                TabComp tabComp = new TabComp();
                tabComp.setIdcomp(rs.getInt("idcompetition"));
                tabComp.setNomco(rs.getString("nomcomp"));
                tabComp.setDatedco(rs.getString("dateDcomp"));
                tabComp.setDatefco(rs.getString("dateFcomp"));

                observableList.add(tabComp);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
// Afficher les données
        TC_TableComp_ID.setCellValueFactory(new PropertyValueFactory<>("idcomp"));
        TC_TableComp_nom.setCellValueFactory(new PropertyValueFactory<>("nomco"));
        TC_TableComp_DateD.setCellValueFactory(new PropertyValueFactory<>("datedco"));
        TC_TableComp_DateF.setCellValueFactory(new PropertyValueFactory<>("datefco"));

        TableView.setItems(observableList);
    };

    public void refreshTableData() {
    }

    public int getIdcompetition() {
        return 0;
    }
}


